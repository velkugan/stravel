from typing import Optional, List
from fastapi import FastAPI, File, UploadFile
from pydantic import BaseModel
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.encoders import jsonable_encoder

import numpy as np
import pandas as pd
import re

app = FastAPI(debug=True)


class Item(BaseModel):
    user_name: dict


@app.post("/files/")
async def create_file(files: bytes = File(...)):
    # async def create_file(files: UploadFile = File(...)):

    df = pd.read_csv("Python Scripts/Dummy_Dataset.csv")

    dup1 = []
    for i, j in zip(df.duplicated().values, df.duplicated().index.values):
        if i:
            dup1.append(j)

    df_dup1 = df.loc[dup1]

    for i, j in zip(df['Account Name'].values, df['Account Name'].index):
        x = re.sub('[^a-z0-9A-Z ]', '', str(i))
        df['Account Name'][j] = re.sub('\s+', ' ', x)

    email_indexes = []
    indexes = []

    for i, j in zip(df['Email'].values, df['Email'].index):
        if type(i) == str:
            x = re.findall(r'[a-zA-Z0-9_+.-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+', i)

            if (x):
                indexes.append(j)
            else:
                email_indexes.append(j)

    df_emails = df.iloc[email_indexes]

    for i in range(len(df)):
        x = re.sub("[^0-9]", "", df['Phone'][i])

        if len(x) == 10:

            if df['Country'].values[i] == 'USA':
                regex = re.compile(r"([\d]{3})([\d]{3})([\d]{4})")
                df['Phone'][i] = re.sub(regex, r"+1 (\1) \2-\3", x)

            elif df['Country'].values[i] == 'France':
                regex = re.compile(r"([\d]{3})([\d]{3})([\d]{4})")
                df['Phone'][i] = re.sub(regex, r"+33 (\1) \2-\3", x)

            elif df['Country'].values[i] == 'India':
                regex = re.compile(r"([\d]{3})([\d]{3})([\d]{4})")
                df['Phone'][i] = re.sub(regex, r"+91 (\1) \2-\3", x)

            elif df['Country'].values[i] == 'UK':
                regex = re.compile(r"([\d]{3})([\d]{3})([\d]{4})")
                df['Phone'][i] = re.sub(regex, r"+44 (\1) \2-\3", x)

    nulls = []
    for val, ind in zip(df.isna().sum().values, df.isna().sum().index):
        if val > 1:
            for i, j in zip(df.isna()[ind].values, df.isna()[ind].index):
                if i:
                    nulls.append(j)

    null_df = df.iloc[list(set(nulls))]

    data_copy = pd.concat([df_dup1, df_emails, null_df], ignore_index=False)

    df = df.loc[indexes]
    df.drop_duplicates(inplace=True)
    df.dropna(inplace=True)

    for i, j in zip(df['Date'].values, df['Date'].index):
        df['Date'][j] = re.sub("[^0-9]", "/", str(i))

    df['Date'] = pd.to_datetime(df['Date'], format='%m/%d/%Y')

    test_indexes = []
    indexes = []
    for i, j in zip(df['Account Name'].values, df['Account Name'].index):
        if type(i) == str:
            i = str.lower(i)
            x = re.findall(r'demo|test|sample', i)
            if (x):
                test_indexes.append(j)
            else:
                indexes.append(j)

    dup2 = []
    for i, j in zip(df.duplicated().values, df.duplicated().index.values):
        if i:
            dup2.append(j)
            indexes.remove(j)

    df_dup2 = df.loc[dup2]

    data_copy2 = pd.concat([data_copy, df_dup2])

    df.drop_duplicates(inplace=True)

    test_df = df.loc[test_indexes]

    main_df = df.loc[indexes]

    data = pd.concat([main_df, test_df, data_copy])

    '''
    data.insert(0, "Description", '')
    data.insert(1, "Remarks", '')

    data['Description'][0:len(main_df)] = 'Golden Data'
    data['Description'][len(main_df):] = 'Faulty Data'
    data['Remarks'][len(main_df):len(main_df)+len(test_df)] = 'Test Accounts'
    data['Remarks'][len(main_df)+len(test_df):] = 'Null and Dublicate Values'
    '''
    json_compatible_item_data = jsonable_encoder(main_df)
    return JSONResponse(content=json_compatible_item_data)
    # return {"file_sizes": [file for file in files]}


'''
@app.post("/uploadfiles/")
async def create_upload_files(files: List[UploadFile] = File(...)):
    return {"filenames": [file.filename for file in files]}

'''


@app.get("/")
async def main():
    content = """
<body>
<form action="/files/" enctype="multipart/form-data" method="post">
<input name="files" type="file" multiple>
<input type="submit">
</form>
</body>
    """

    return HTMLResponse(content=content)
